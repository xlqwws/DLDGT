
from framework_component import FunctionalComponent

class BaseSequential(FunctionalComponent):
    pass